package ast;

public enum KindI {CONDICIONAL, ASIGNACION, DECLARACION}
