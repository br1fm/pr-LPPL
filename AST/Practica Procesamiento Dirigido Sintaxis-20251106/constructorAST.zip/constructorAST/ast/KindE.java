package ast;

public enum KindE {EBIN, BOOL, NUM, ID}
