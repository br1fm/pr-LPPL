package ast;

public enum BinOps {
    MAS, IGUAL, MAYOR
}
