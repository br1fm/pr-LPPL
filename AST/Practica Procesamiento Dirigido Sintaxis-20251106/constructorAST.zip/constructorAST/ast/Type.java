package ast;

public enum Type {
    BOOL,NUM
}
