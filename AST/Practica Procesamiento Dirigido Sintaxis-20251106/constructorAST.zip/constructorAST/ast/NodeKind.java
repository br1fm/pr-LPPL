package ast;

public enum NodeKind {
  EXPRESION, INSTRUCCION
}
